# Character Maker (फोटो -> गेम कैरेक्टर)

दो हिस्से हैं:
- backend/  : Python (FastAPI + rembg + AnimeGANv2). यह सर्वर पर या PC पर चलता है, APK के अंदर नहीं।
- app/      : सफ़ेद थीम वाला ऐप (HTML/JS + Capacitor)। इसी से APK बनेगा।

## 1) Backend चलाओ
    cd backend
    python -m venv venv
    source venv/bin/activate        # Windows: venv\Scripts\activate
    pip install -r requirements.txt
    uvicorn main:app --host 0.0.0.0 --port 8000

पहली बार मॉडल डाउनलोड होंगे (इंटरनेट चाहिए)।
टेस्ट: http://localhost:8000/docs

## 2) APK बनाओ
ज़रूरी: Node 18+, JDK 17, Android Studio
    cd app
    npm install
    npx cap add android
    npx cap sync android
    npx cap open android
Android Studio में: Build > Build Bundle(s) / APK(s) > Build APK(s)

## 3) ऐप में सर्वर का पता
ऐप खोलकर ⚙ दबाओ और सर्वर का पता डालो:
- Android Emulator: http://10.0.2.2:8000
- असली फोन (PC और फोन एक ही WiFi पर): http://<PC-का-IP>:8000
- Deploy किया हो तो: उसका https लिंक

## नोट
- Pixel स्टाइल बिना सर्वर के भी फोन में चल जाता है (पर बैकग्राउंड नहीं हटता)।
- Anime स्टाइल और बैकग्राउंड हटाने के लिए सर्वर ज़रूरी है।
- main.py में allow_origins=["*"] है। डिप्लॉय करते समय इसे सीमित करो।
- Play Store पर डालना हो तो capacitor.config.json में appId बदलो, और https वाला सर्वर इस्तेमाल करो।
