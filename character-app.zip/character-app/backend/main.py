import io

import numpy as np
import torch
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from PIL import Image, ImageOps, UnidentifiedImageError
from rembg import new_session, remove

SIZE = 512
MAX_UPLOAD = 10 * 1024 * 1024  # 10 MB

app = FastAPI(title="Photo to Game Character")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

# Models ek baar load hote hain. Pehli baar chalane par internet se download honge.
torch.set_grad_enabled(False)
rembg_session = new_session("u2net")
anime_model = torch.hub.load(
    "bryandlee/animegan2-pytorch:main",
    "generator",
    pretrained="face_paint_512_v2",
    trust_repo=True,
).eval()


def to_anime(img: Image.Image) -> Image.Image:
    arr = np.asarray(img, dtype=np.float32) / 255.0
    x = torch.from_numpy(arr).permute(2, 0, 1).unsqueeze(0) * 2 - 1
    out = anime_model(x, False).squeeze(0).clamp(-1, 1) * 0.5 + 0.5
    out = (out.permute(1, 2, 0).numpy() * 255).astype(np.uint8)
    return Image.fromarray(out)


def to_pixel(img: Image.Image, pixel_size: int = 64, colors: int = 16) -> Image.Image:
    small = img.resize((pixel_size, pixel_size), Image.BILINEAR)
    small = small.quantize(colors=colors).convert("RGB")
    return small.resize((SIZE, SIZE), Image.NEAREST)


# "def" (async nahi) taaki bhaari kaam threadpool me chale aur server atke nahi
@app.post("/character")
def make_character(
    file: UploadFile = File(...),
    style: str = Form("anime"),  # "anime" ya "pixel"
    remove_bg: bool = Form(True),
):
    raw = file.file.read(MAX_UPLOAD + 1)
    if len(raw) > MAX_UPLOAD:
        raise HTTPException(413, "Photo 10 MB se badi hai")
    try:
        img = Image.open(io.BytesIO(raw))
        img = ImageOps.exif_transpose(img).convert("RGB")
    except (UnidentifiedImageError, OSError):
        raise HTTPException(400, "Yeh photo nahi khul paayi")

    img = ImageOps.fit(img, (SIZE, SIZE))  # square crop + resize
    styled = to_pixel(img) if style == "pixel" else to_anime(img)

    if remove_bg:
        mask = remove(img, session=rembg_session, only_mask=True)
        styled = styled.convert("RGBA")
        styled.putalpha(mask.convert("L").resize(styled.size))

    buf = io.BytesIO()
    styled.save(buf, format="PNG")
    return Response(content=buf.getvalue(), media_type="image/png")


@app.get("/")
def health():
    return {"status": "ok"}
